plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "ru.kolonka.control"
    compileSdk = 35

    defaultConfig {
        applicationId = "ru.kolonka.control"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "2.0"
    }
}
