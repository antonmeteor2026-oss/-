package ru.kolonka.control

import android.app.Activity
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.Virtualizer
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private val bg = Color.rgb(3, 10, 7)
    private val panel = Color.rgb(10, 27, 19)
    private val green = Color.rgb(35, 235, 125)
    private val muted = Color.rgb(167, 190, 177)
    private var virtualizer: Virtualizer? = null
    private var bass: BassBoost? = null
    private var equalizer: Equalizer? = null
    private var virtualizerAvailable = false
    private var bassAvailable = false
    private var eqAvailable = false
    private var threeDEnabled = false
    private var threeDStrength = 70
    private var bassStrength = 45
    private var eqEnabled = false
    private var voiceEnabled = false
    private var currentPage = "home"
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = 0
        initAudioEffects()
        showHome()
    }

    private fun initAudioEffects() {
        try {
            virtualizer = Virtualizer(0, 0)
            virtualizerAvailable = virtualizer?.hasControl() == true
        } catch (_: Exception) { virtualizerAvailable = false }
        try {
            bass = BassBoost(0, 0)
            bassAvailable = bass?.hasControl() == true
        } catch (_: Exception) { bassAvailable = false }
        try {
            equalizer = Equalizer(0, 0)
            eqAvailable = equalizer?.hasControl() == true
        } catch (_: Exception) { eqAvailable = false }
    }

    private fun showHome() {
        currentPage = "home"
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(10), dp(18), dp(14))
            setBackgroundColor(bg)
        }
        val scroll = ScrollView(this).apply { isFillViewport = true }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        val header = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            orientation = LinearLayout.HORIZONTAL
        }
        val menu = label("☰", 30, green, true)
        header.addView(menu, weightParams(48))
        val brand = label("♫  Колонка ", 24, Color.WHITE, true)
        val accent = label("Контроль", 24, green, true)
        val brandRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        brandRow.addView(brand); brandRow.addView(accent)
        header.addView(brandRow, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(label("⚙", 28, Color.WHITE, true))
        content.addView(header)
        content.addView(label("●  Яндекс Станция Макс     ·     Дизайн-предпросмотр", 13, muted, false).apply {
            setPadding(dp(50), dp(8), 0, dp(8))
        })

        val speakerCard = card()
        speakerCard.setPadding(dp(16), dp(12), dp(16), dp(14))
        speakerCard.addView(label("ЯНДЕКС СТАНЦИЯ МАКС", 12, green, true))
        val speaker = label("Я", 92, Color.rgb(85, 255, 157), true).apply {
            gravity = Gravity.CENTER
            background = rounded(Color.rgb(8, 74, 39), 34, green, 2)
            setPadding(0, dp(6), 0, dp(6))
        }
        speakerCard.addView(speaker, LinearLayout.LayoutParams(-1, dp(170)))
        speakerCard.addView(label("Колонка пока не подключена к приложению", 12, muted, false).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, 0)
        })
        content.addView(speakerCard, marginParams(bottom = 12))

        val volumeCard = card()
        volumeCard.addView(label("Громкость устройства", 17, Color.WHITE, true))
        volumeCard.addView(label("Регулятор демонстрационный — не меняет громкость Яндекс Станции", 12, muted, false))
        val vol = SeekBar(this).apply { max = 100; progress = 70; progressTintList = android.content.res.ColorStateList.valueOf(green); thumbTintList = android.content.res.ColorStateList.valueOf(green) }
        volumeCard.addView(vol)
        content.addView(volumeCard, marginParams(bottom = 12))

        val spatial = card()
        spatial.addView(label("◇  ПРОСТРАНСТВЕННОЕ ЗВУЧАНИЕ", 17, green, true))
        spatial.addView(label("Объёмный 3D-эффект вокруг вас", 13, muted, false))
        val toggleRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val status = label(if (threeDEnabled) "Включено" else "Выключено", 14, Color.WHITE, true)
        toggleRow.addView(status, LinearLayout.LayoutParams(0, -2, 1f))
        val toggle = Switch(this).apply {
            isChecked = threeDEnabled
            buttonTintList = android.content.res.ColorStateList.valueOf(green)
            setOnCheckedChangeListener { _, checked ->
                threeDEnabled = checked
                applyVirtualizer()
                status.text = if (checked) "Включено" else "Выключено"
            }
        }
        toggleRow.addView(toggle)
        spatial.addView(toggleRow)
        spatial.addView(label("Интенсивность эффекта: $threeDStrength%", 14, Color.WHITE, true))
        val strength = SeekBar(this).apply {
            max = 100; progress = threeDStrength
            progressTintList = android.content.res.ColorStateList.valueOf(green)
            thumbTintList = android.content.res.ColorStateList.valueOf(green)
            setOnSeekBarChangeListener(simpleSeek { value ->
                threeDStrength = value
                (spatial.getChildAt(3) as TextView).text = "Интенсивность эффекта: $value%"
                applyVirtualizer()
            })
        }
        spatial.addView(strength)
        val note = label(audioStatus3D(), 12, muted, false)
        spatial.addView(note)
        val details = button("Расширенные настройки  ›") { showPage("spatial") }
        spatial.addView(details)
        content.addView(spatial, marginParams(bottom = 14))

        val grid = GridLayout(this).apply { columnCount = 2; useDefaultMargins = true }
        val tiles = listOf(
            "Эквалайзер" to "Настройка частот",
            "Бас" to "Низкие частоты",
            "Улучшение голоса" to "Чёткость речи",
            "3D-звук" to "Пространственный эффект"
        )
        tiles.forEach { (title, sub) ->
            val tile = card().apply {
                addView(label(title, 17, green, true))
                addView(label(sub, 12, muted, false))
                setOnClickListener { showPage(when (title) { "Эквалайзер" -> "eq"; "Бас" -> "bass"; "Улучшение голоса" -> "voice"; else -> "spatial" }) }
            }
            val p = GridLayout.LayoutParams().apply {
                width = 0; height = dp(92); columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(4), dp(4), dp(4), dp(4))
            }
            grid.addView(tile, p)
        }
        content.addView(grid)
        content.addView(label("Эффекты Android могут обрабатывать звук этого телефона, но не гарантируют обработку музыки, которая играет напрямую на колонке.", 11, muted, false).apply {
            setPadding(dp(4), dp(12), dp(4), dp(8))
        })
    }

    private fun showPage(page: String) {
        currentPage = page
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            setBackgroundColor(bg)
        }
        setContentView(root)
        root.addView(button("‹  На главный экран") { showHome() })
        val title = when (page) {
            "spatial" -> "Пространственное звучание"
            "eq" -> "Эквалайзер"
            "bass" -> "Бас"
            else -> "Улучшение голоса"
        }
        root.addView(label(title, 26, Color.WHITE, true).apply { setPadding(0, dp(22), 0, dp(8)) })
        when (page) {
            "spatial" -> {
                root.addView(label("Управление виртуализатором Android", 14, muted, false))
                val sw = Switch(this).apply {
                    text = "Включить 3D-эффект"; setTextColor(Color.WHITE); isChecked = threeDEnabled
                    setOnCheckedChangeListener { _, checked -> threeDEnabled = checked; applyVirtualizer() }
                }
                root.addView(sw)
                root.addView(label("Сила эффекта: $threeDStrength%", 16, green, true))
                root.addView(seek(threeDStrength) { v -> threeDStrength = v; applyVirtualizer(); (root.getChildAt(4) as TextView).text = "Сила эффекта: $v%" })
                root.addView(label(audioStatus3D(), 13, muted, false))
            }
            "bass" -> {
                root.addView(label("Усиление низких частот", 14, muted, false))
                root.addView(label("Сила баса: $bassStrength%", 16, green, true))
                root.addView(seek(bassStrength) { v -> bassStrength = v; applyBass(); (root.getChildAt(2) as TextView).text = "Сила баса: $v%" })
                root.addView(label(if (bassAvailable) "Эффект баса доступен на этом устройстве." else "Системный эффект баса недоступен на этом устройстве.", 13, muted, false))
            }
            "eq" -> {
                root.addView(label(if (eqAvailable) "Системный эквалайзер обнаружен." else "Системный эквалайзер недоступен на этом устройстве.", 13, muted, false))
                val bands = equalizer?.numberOfBands?.toInt() ?: 0
                if (bands > 0) {
                    for (i in 0 until bands) {
                        val range = equalizer!!.getBandLevelRange()
                        val min = range[0].toInt(); val max = range[1].toInt()
                        val label = label("Полоса ${i + 1}", 15, Color.WHITE, true)
                        root.addView(label)
                        val seek = SeekBar(this).apply {
                            this.max = max - min
                            progress = (equalizer!!.getBandLevel(i.toShort()).toInt() - min).coerceIn(0, this.max)
                            progressTintList = android.content.res.ColorStateList.valueOf(green)
                            thumbTintList = android.content.res.ColorStateList.valueOf(green)
                            setOnSeekBarChangeListener(simpleSeek { v -> try { equalizer!!.setBandLevel(i.toShort(), (v + min).toShort()) } catch (_: Exception) {} })
                        }
                        root.addView(seek)
                    }
                } else {
                    root.addView(label("На этом телефоне полосы эквалайзера не предоставлены системой.", 13, muted, false))
                }
            }
            else -> {
                val sw = Switch(this).apply {
                    text = "Улучшение голоса"; setTextColor(Color.WHITE); isChecked = voiceEnabled
                    setOnCheckedChangeListener { _, checked -> voiceEnabled = checked }
                }
                root.addView(sw)
                root.addView(label("Этот переключатель пока управляет режимом интерфейса. Отдельный системный эффект обработки голоса Android не предоставил.", 13, muted, false))
            }
        }
    }

    private fun applyVirtualizer() {
        try {
            virtualizer?.enabled = threeDEnabled && virtualizerAvailable
            if (virtualizerAvailable) virtualizer?.setStrength((threeDStrength * 10).toShort())
        } catch (_: Exception) {}
    }

    private fun applyBass() {
        try {
            bass?.enabled = bassStrength > 0 && bassAvailable
            if (bassAvailable) bass?.setStrength((bassStrength * 10).toShort())
        } catch (_: Exception) {}
    }

    private fun audioStatus3D(): String = when {
        !virtualizerAvailable -> "3D-эффект Android не поддерживается или недоступен на этом устройстве."
        else -> "Эффект Android доступен. Работа с музыкой из других приложений зависит от устройства и аудиомаршрута."
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(15), dp(16), dp(15))
        background = rounded(panel, 24, Color.rgb(26, 103, 62), 1)
    }

    private fun button(text: String, action: () -> Unit): TextView =
        label(text, 15, Color.WHITE, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(14), dp(12), dp(14))
            background = rounded(Color.rgb(17, 47, 32), 18, green, 1)
            setOnClickListener { action() }
        }

    private fun label(text: String, size: Int, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size.toFloat()
            setTextColor(color)
            typeface = if (bold) Typeface.create("sans-serif", Typeface.BOLD) else Typeface.create("sans-serif", Typeface.NORMAL)
        }

    private fun rounded(color: Int, radius: Int, stroke: Int, strokeWidth: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color); cornerRadius = dp(radius).toFloat()
            setStroke(dp(strokeWidth), stroke)
        }

    private fun seek(value: Int, onChange: (Int) -> Unit): SeekBar =
        SeekBar(this).apply {
            max = 100; progress = value
            progressTintList = android.content.res.ColorStateList.valueOf(green)
            thumbTintList = android.content.res.ColorStateList.valueOf(green)
            setOnSeekBarChangeListener(simpleSeek(onChange))
        }

    private fun simpleSeek(onChange: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) { if (fromUser) onChange(progress) }
        override fun onStartTrackingTouch(seekBar: SeekBar?) {}
        override fun onStopTrackingTouch(seekBar: SeekBar?) {}
    }

    private fun weightParams(width: Int) = LinearLayout.LayoutParams(dp(width), -2)
    private fun marginParams(bottom: Int = 0) = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(bottom) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).roundToInt()

    override fun onDestroy() {
        try { virtualizer?.release() } catch (_: Exception) {}
        try { bass?.release() } catch (_: Exception) {}
        try { equalizer?.release() } catch (_: Exception) {}
        super.onDestroy()
    }
}
